<html>
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <title>Pagina de Produtos</title>
    <style>
        body {
          padding: 20px;
        }
        .navbar {
          margin-bottom: 20px;
        }
    </style>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>

  <div class="container">
    <div class="card text-center">
      <div class="card-header">
       	Tabela de Clientes 
      </div>
      <div class="card-body">
        <h5 class="card-title">Exibindo <?php echo e($clientes->count()); ?> clientes de <?php echo e($clientes->total()); ?> 
        ( <?php echo e($clientes->firstItem()); ?> a <?php echo e($clientes->lastItem()); ?> ) </h5>

        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nome</th>
              <th scope="col">Sobrenome</th>
              <th scope="col">Email</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($cliente->id); ?></th>
              <td><?php echo e($cliente->nome); ?></td>
              <td><?php echo e($cliente->sobrenome); ?>Otto</td>
              <td><?php echo e($cliente->email); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="card-footer">
        <?php echo e($clientes->links()); ?> 
      </div>
    </div>

  </div>

  <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>

</body>
</html>
