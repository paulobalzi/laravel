<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Categoria; 

Route::get('/', function () {
    return view('welcome');
});

Route::get('/listar', function () {
    $cats = Categoria::all();
    foreach($cats as $cat) {
        echo "id: " . $cat->id . ", ";
        echo "nome: " . $cat->nome . "<br>";
    }
});

Route::get('/inserir/{nome}', function ($nome) {
    $cat = new Categoria();
    $cat->nome = $nome;
    $cat->save();
    return redirect('/listar');
});


Route::get('/ver/{id}', function ($id) {
    $cat = Categoria::find($id);
    echo "id: " . $cat->id . ", ";
    echo "nome: " . $cat->nome . "<br>";
});

Route::get('/atualizar/{id}/{novonome}', function ($id, $novonome) {
    $cat = Categoria::find($id);
    $cat->nome = $novonome;
    $cat->save();
    return redirect('/listar');
});

Route::get('/apagar/{id}', function ($id) {
    $cat = Categoria::find($id);
    $cat->delete();
    return redirect('/listar');
});

