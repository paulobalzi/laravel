<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Usuário</div>

                <div class="card-body">
                    <?php if(auth()->guard()->check()): ?>
                        <h1>Usuário Autenticado</h1>
                        <hr>
                        <h4>Nome: <?php echo e(Auth::user()->name); ?></h4>
                        <h4>email: <?php echo e(Auth::user()->email); ?></h4>

                    <?php endif; ?>

                    <?php if(auth()->guard()->guest()): ?>
                        <h1>Usuário NÃO Autenticado</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>